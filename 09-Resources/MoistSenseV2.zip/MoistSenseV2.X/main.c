#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/pwm/pwm1_16bit.h"   // <? your PWM header

//===========================================================
// TIMING + THRESHOLDS
//===========================================================

#define STEP_DELAY_US    10      // timing resolution per loop
#define MAX_COUNT        5000    // safety cap; 5000 * 10 �s = 50 ms

// You?ll tune these after testing:
//
// Smaller count  -> charges fast  -> LOWER capacitance -> DRIER
// Bigger count   -> charges slow  -> HIGHER capacitance -> WETTER
//
#define COUNT_DRY_MAX    800     // <= this = ?DRY?
#define COUNT_DAMP_MAX   2000    // <= this = ?DAMP?; > this = ?VERY WET?

#define LOOP_DELAY_MS    250     // delay between measurements

//===========================================================
//  Discharge the probe node
//===========================================================
static void DischargeProbe(void)
{
    // Stop PWM so RF7 is not toggling
    PWM1_16BIT_Disable();

    // Force RF7 low
    IO_RF7_SetDigitalOutput();
    IO_RF7_SetLow();

    // Force RA0 low as well to fully discharge
    IO_RA0_SetDigitalOutput();
    IO_RA0_SetLow();

    __delay_ms(1);    // give time to discharge
}

//===========================================================
//  MeasureChargeTime
//   - Discharge sensor
//   - Enable PWM on RF7
//   - Count how long until RA0 reads HIGH
//===========================================================
static uint16_t MeasureChargeTime(void)
{
    uint16_t count = 0;

    // 1) Discharge node
    DischargeProbe();

    // 2) Let RA0 float and start PWM on RF7
    IO_RA0_SetDigitalInput();     // sensor node now allowed to charge

    // Initialize PWM if not already done, then enable it
    PWM1_16BIT_Initialize();      // sets period/duty from MCC config
    PWM1_16BIT_Enable();          // begin PWM excitation on RF7

    // 3) Count until RA0 sees a logic HIGH, or until MAX_COUNT
    while (!IO_RA0_GetValue() && (count < MAX_COUNT))
    {
        __delay_us(STEP_DELAY_US);
        count++;
    }

    // 4) Stop PWM and pull RF7 low again
    PWM1_16BIT_Disable();
    IO_RF7_SetLow();

    return count;
}

//===========================================================
// MAIN
//===========================================================
int main(void)
{
    SYSTEM_Initialize();

    // Status LED ON so you know code is running (RE0)
    IO_RE0_SetHigh();

    // Debug LED off initially (RC7)
    IO_RC7_SetLow();

    while (1)
    {
        // 1) Measure ?moisture? as a charge-time count
        uint16_t t = MeasureChargeTime();

        // 2) Map t into zones:
        //
        //    t <= COUNT_DRY_MAX   -> DRY (fast charge)
        //    t <= COUNT_DAMP_MAX  -> DAMP
        //    t  > COUNT_DAMP_MAX  -> VERY WET (slow charge)
        //
        uint8_t zone;
        if (t <= COUNT_DRY_MAX)
        {
            zone = 3;    // DRY
        }
        else if (t <= COUNT_DAMP_MAX)
        {
            zone = 2;    // DAMP
        }
        else
        {
            zone = 1;    // VERY WET
        }

        // 3) Drive RC7 LED according to zone:
        //
        //   Zone 3 (DRY)       : solid ON
        //   Zone 2 (DAMP)      : slow blink
        //   Zone 1 (VERY WET)  : OFF
        //
        static uint16_t blinkCounter = 0;
        blinkCounter++;

        if (zone == 3)
        {
            // DRY -> solid ON
            IO_RC7_SetHigh();
        }
        else if (zone == 2)
        {
            // DAMP -> slow blink (toggle every 4 loops)
            if (blinkCounter >= 4)
            {
                IO_RC7_Toggle();
                blinkCounter = 0;
            }
        }
        else // zone == 1
        {
            // VERY WET -> off
            IO_RC7_SetLow();
        }

        __delay_ms(LOOP_DELAY_MS);
    }
}
